const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Touch,
		C3.Plugins.Text,
		C3.Plugins.Sprite,
		C3.Plugins.Mouse,
		C3.Plugins.Audio,
		C3.Plugins.Touch.Cnds.OnTapGestureObject,
		C3.Plugins.Audio.Acts.StopAll,
		C3.Plugins.Audio.Acts.Play,
		C3.Plugins.Sprite.Acts.SetAnimFrame,
		C3.Plugins.Audio.Acts.ScheduleNextPlay,
		C3.Plugins.Audio.Cnds.IsSilent
	];
};
self.C3_JsPropNameTable = [
	{Touch: 0},
	{Text: 0},
	{Sprite: 0},
	{Maus: 0},
	{play: 0},
	{Audio: 0},
	{Sprite2: 0},
	{Sprite3: 0},
	{Sprite4: 0},
	{Sprite5: 0},
	{Sprite6: 0}
];

self.InstanceType = {
	Touch: class extends self.IInstance {},
	Text: class extends self.ITextInstance {},
	Sprite: class extends self.ISpriteInstance {},
	Maus: class extends self.IInstance {},
	play: class extends self.ISpriteInstance {},
	Audio: class extends self.IInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	Sprite4: class extends self.ISpriteInstance {},
	Sprite5: class extends self.ISpriteInstance {},
	Sprite6: class extends self.ISpriteInstance {}
}